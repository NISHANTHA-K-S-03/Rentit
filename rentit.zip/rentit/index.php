<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>RentIt!</title>

    <!-- custom link to css file -->
    <link rel="stylesheet" href="./style.css">

    <!-- custom links to font style -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;800&display=swap" rel="stylesheet">
</head>
<body>
    <section class="header">
        <header >
            <nav>
                <div id="navigation">
                    <div class="navbar-logo">
                    <a href="#" class="navbar-logo-link">
                      <img src="images/logo.png" alt="Logo">
                    </a>
                    </div>
                    <div class="navbar-contents">
                        <ul>
                            <li><a href="#home">home</a></li>
                            <li><a href="#purposes-section">purpose</a></li>
                            <li><a href="#services-section">categories</a></li>
                            <li><a href="aboutus.html">about</a></li>
                            <li><a href="#about-section">others</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header> 
    </section>

    <section id="home">
        <div class="main-body">
            <div class="main-body-content">
                <h1>RENT MORE, BUY LESS</h1>
                <p>Find everything you need for your short-term needs at RentIt. We offer a wide variety of items available for rent, from tools and equipment to electronics, musical, medical tools and many more. Renting is a cost-effective and convenient way to access the items you need without the hassle of purchasing and storing them.</p>
                <div class="btn">
                    <a href="login&register.php"><button class="button">login</button></a>
                    <a href="learnmore.html"><button class="button">Learn more</button></a>
                </div>
            </div>
            <div class="main-body-img">
                <img src="./images/services.jpg" alt="image" >
            </div>
        </div>
    </section>

    <section id="purposes-section">
    <section class="purposes">
        <!-- <h1>purposes</h1> -->
        <div class="purposes-details">
            <div class="purpose-col">
                <img src="./images/give_rent.jpg" alt="" class="img-1">
                <a href="./login&register.php">rent</a>
                <p>add details of your product with photo and price</p>
            </div>
            <div class="purpose-col">
                <img src="./images/take_rent.jpg" alt="" class="img-2
                ">
                <a href="./login&register.php">lease</a>
                <p>select your product with no. of days of use</p>
            </div>
        </div>
    </section>
</section>

<section id="services-section">
        <div>
            <!-- <h1 class="service-heading">categories</h1> -->
        </div>
        <div class="service">
            <a href="#purposes-section"> <div class="container-s">
              <img src="./images/books_renting.jpg" alt="Avatar" class="image">
              <div class="overlay">
                <div class="text"><h5 class="txt">books and stationaries</h5>
              <p>Textbooks, Novels, Fiction Books, Reference Books, Study Guides, Exam Preparation Materials, Art Supplies, Office Supplies, Presentation Materials, Craft Supplies and many more</p></div>
              </div></a>
              </div>

            <a href="#purposes-section"><div class="container-s">
              <img src="./images/clothing_renting.jpg" alt="Avatar" class="image">
              <div class="overlay">
                <div class="text"><h5 class="txt">clothes and accessories</h5>
              <p>Dresses Suits, Formal Wear, Wedding Attire Party, Dresses Costumes, Designer Clothing, Handbags, Jewelry, Hats, Scarves, Ties, Belts, Sunglasses, Watches</p></div>
              </div>
            </div></a>

            <a href="#purposes-section"><div class="container-s">
              <img src="./images/camera_renting.jpg" alt="Avatar" class="image">
              <div class="overlay">
                <div class="text"><h5 class="txt">elctronic gadgets</h5>
              <p>Smartphones
Laptops
Tablets
Cameras
Drones
Virtual Reality (VR) Headsets
Gaming Consoles
Projectors
Smartwatches
Fitness Trackers
Portable Speakers
Headphones
Printers
Monitors
GPS Devices</p></div>
              </div>
            </div></a>
            </div>

              <div class="service-1">
                <a href="#purposes-section"> <div class="container-1">
                  <img src="./images/party_decorations.jpg" alt="Avatar" class="image-1">
                  <div class="overlay-1">
                    <div class="text-1"><h5 class="txt">party and festivals</h5>
                      <p>Party Tents
Tables and Chairs
Lighting Equipment
Sound Systems
DJ Equipment
Dance Floors
Projectors and Screens
Photo Booths
Party Games and Activities
Barbecue Grills
Party Decorations
Portable Bars
Staging Equipment</p></div>
                  </div>
                  </div></a>
                  <a href="#purposes-section"><div class="container-1">
                    <img src="./images/medical_help.jpg" alt="Avatar" class="image-1">
                    <div class="overlay-1">
                        <div class="text-1"><h5 class="txt">medical equipments</h5>
                            <p>Wheelchairs, Hospital Beds, Mobility Scooters, Crutches, Walkers, Patient Lifts, Oxygen Concentrators, NebulizersCPAP MachinesHome Ventilators, Blood Pressure Monitors, Termometers etc</p></div>
                    </div>
                </div></a>
                <a href="#purposes-section"><div class="container-1">
                  <img src="./images/collaged_image.png" alt="Avatar" class="image-1">
                  <div class="overlay-1">
                      <div class="text-1"><h5 class="txt">others</h5>
                          <p>Camping Tents, Bicycles, Kayaks, Surfboards, Power Tools, Lawn Mowers, Generators, Baby Gear, Projectors, Speakers, Microphones, Golf Clubs, Exercise Bikes, Treadmills, Party Costumes, Tuxedos, Evening Gowns, Guitars, Keyboards, Drums.</p></div>
                  </div>
              </div></a>
            </div>
        </div>
    </section>

    <section class="faq" id="about-section">
        <div class="heading-faq">
            <h1>faq</h1>
        </div>
        <div class="container-faq">
            <div class="accordion">
              <div class="accordion-item">
                <button id="accordion-button-1" aria-expanded="false">
                  <span class="accordion-title">What is the rental period and how is it calculated?</span>
                  <span class="icon" aria-hidden="true"></span>
                </button>
                <div class="accordion-content">
                  <p>
                  The rental period is the duration for which you can use the rented item. It can be calculated based on a daily, hourly, or fixed duration basis, depending on the rental service's policies.
                  </p>
                </div>
              </div>
              <div class="accordion-item">
                <button id="accordion-button-2" aria-expanded="false">
                  <span class="accordion-title">Can I cancel a rental booking?</span>
                  <span class="icon" aria-hidden="true"></span>
                </button>
                <div class="accordion-content">
                  <p>
                  Yes, cancellation policies may vary depending on the rental service. In general, most rental platforms allow users to cancel their booking, but the specific terms and conditions may determine if any cancellation fees or penalties apply. It's important to review the rental service's cancellation policy before making a booking to understand the cancellation process and any associated charges. If you need to cancel a rental booking, contact the rental provider or follow the instructions provided on the rental platform to initiate the cancellation.
                  </p>
                </div>
              </div>
              <div class="accordion-item">
                <button id="accordion-button-3" aria-expanded="false">
                  <span class="accordion-title">Is there insurance coverage for rented items?</span>
                  <span class="icon" aria-hidden="true"></span>
                </button>
                <div class="accordion-content">
                  <p>Insurance coverage for rented items may be available, but it depends on the rental service. Please review the rental service's policies to understand if insurance options are offered and the terms associated with them.
                  </p>
                </div>
              </div>
              <div class="accordion-item">
                <button id="accordion-button-4" aria-expanded="false">
                  <span class="accordion-title">How can I contact the rental provider for any questions or concerns?</span>
                  <span class="icon" aria-hidden="true"></span>
                </button>
                <div class="accordion-content">
                  <p>
                    To contact the rental provider for any questions or concerns, you can typically find their contact information on the rental platform or website. Look for a customer support phone number, email address, or messaging system provided by the rental service. Reach out to them directly with your inquiries, and they will assist you accordingly.
                  </p>
                </div>
              </div>
              <div class="accordion-item">
                <button id="accordion-button-5" aria-expanded="false">
                  <span class="accordion-title">What happens if the rented item is not available when I need it?</span>
                  <span class="icon" aria-hidden="true"></span>
                </button>
                <div class="accordion-content">
                  <p>
                  If the rented item is not available when you need it, it is advisable to contact the rental provider as soon as possible. They can provide you with alternative options or assist in finding a suitable replacement item. Communication is key in such situations to ensure a resolution that meets your needs. The rental provider will work with you to address the issue and find a satisfactory solution, which may involve rescheduling the rental or providing a refund if necessary.
                  </p>
                </div>
              </div>
            </div>
          </div>
       
        </section>

      </section>

      <section class="blogs">
        <div class="blog">
          <div class="blog-heading">
              <h1>Customer's Review</h1>
          </div>
  
  
          <div class="blog-box">
              <div class="blog-col">
                  <img src="./images/pini.png" alt="">
  
                  <p>"RentIt has been a lifesaver for me! I needed a pressure washer for a weekend project, and renting one through this platform was a breeze. The item was in excellent condition, and the rental process was smooth from start to finish. The customer support team was also very responsive and helpful. I highly recommend RentIt for anyone in need of short-term rentals. Five stars!" <br>
                  <p class="b-p">
                  <p>--praveen karikal.</p>
                  </p>
                  </p>
  
              </div>
              <div class="blog-col">
                  <img src="./images/pic-4.png" alt="">
  
                  <p>"Renting a party tent through RentIt was a fantastic experience! The rental provider was professional, the tent was set up perfectly, and the communication was excellent. I highly recommend RentIt for all your rental needs!"<br>
                  <p class="b-p">
                  <p>--parvathi durgabhavani</p>
                  </p>
              </div>
          </div>
      </div>
  
      </section>


        <section class="footer">
            <footer class="footer-distributed">

                <div class="footer-left">
    
                    <h3>Rent<span>It!</span></h3>
    
                    <p class="footer-links">
                        <a href="#home" class="link-1">Home</a>
                        
                        <a href="#">Blog</a>
                    
                        <a href="#services-section">categories</a>
                    
                        <a href="aboutus.html">About</a>
                        
                        <a href="#about-section">Faq</a>
                        
                        <a href="#about-section">Contact</a>
                    </p>
    
                    <p class="footer-company-name">Company Name © 2023</p>
                </div>
    
                <div class="footer-center">
    
                    <div>
                        <i class="fa fa-map-marker"></i>
                        <p><span>BMSIT&M</span> Yelahanka, bengaluru</p>
                    </div>
    
                    <div>
                        <i class="fa fa-phone"></i>
                        <p>+91 97437 95366</p>
                    </div>
    
                    <div>
                        <i class="fa fa-envelope"></i>
                        <p><a href="mailto:support@company.com">rentit@gmail.com</a></p>
                    </div>
    
                </div>
    
                <div class="footer-right">
    
                    <p class="footer-company-about">
                        <span>About the company</span>
                        RentIt: Your trusted platform for convenient and cost-effective rentals. Find what you need, when you need it. Simplify, save, and share!
                    </p>
    
                    <div class="footer-icons">
    
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                        <a href="#"><i class="fa fa-github"></i></a>
    
                    </div>
    
                </div>
    
            </footer>
        
    <style>
      *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Montserrat', sans-serif;
}

body,html{
    scroll-behavior: smooth;
}

/* navigation bar section starts */

header{
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 15vh;
    transition: 1s;
    z-index: 100;
}

nav{
    height: 100%;
    width: 100%;
    background-color: #fff;
    transition: 1s;
}

#navigation{
    display: flex;
    justify-content: space-between;
    z-index: 100;
}

nav.hide{
    transform: translateY(-100%);
}

.navbar-logo img{
    padding-top: 3vh;
    height: 120px;
    
    /* display: none; */
}

.navbar-logo a{
    padding-left: 5vw;
}

.navbar-contents{
    padding-top: 6vh;
    flex-basis: 80%;
}

.navbar-contents ul{
    display: flex;
    justify-content: space-evenly;
}

.navbar-contents ul li{
    list-style: none;
}

.navbar-contents ul li a{
    text-decoration: none;
    color: navy;
    padding: 20px;
    font-size: 17px;
    text-transform: uppercase;
    font-weight: 600;
    font-family: 'Montserrat', sans-serif;
    transition: all 0.5s;
}

.navbar-contents ul li a:hover{
    color: #845007;
}

/* navigation bar section ends */
.main-body-content{
    padding-top: 30vh;
}
.main-body{
    margin-top: 11vh;
    background-color: #c2dde6;
    height: 89vh;
    display: flex;
    justify-content: space-between;
}

.main-body h1{
    padding-left: 5vw;
    font-size: 30px;
}

.main-body p{
    padding-left: 5vw;
    padding-top: 3vh;
}


.main-body-img img{
    height: 50vh;
    margin-top: 13vh;
    margin-right: 5vw;
    border-radius: 46% 54% 26% 74% / 57% 43% 57% 43%;
    box-shadow: 30px 10px 100px #f7f7f7;
}

/* button code */
.btn{
    margin-top: 10vh;
    margin-left: 5vw;
}

.button{
    height: 70px;
    width: 200px;
    border-radius: 40px;
    text-transform: uppercase;
    border: none;
    overflow: hidden;
    box-shadow: 0 0 0 0 rgba(143,64,248,0.5),0 0 0 0 rgba(39,200,255,0.5);
    background-image: linear-gradient(225deg, #27d86c 0%, #26caf8 50%, #c625d0 100%);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
}

.button::after{
    content: "";
    width: 400px;
    height: 400px;
    position: absolute;
    top: -50px;
    left: -100px;
    background-color: #ff3cac;
    background-image: linear-gradient(225deg, #27d86c 0%, #26caf8 50%, #c625d0 100%);
    z-index: -1;
    transition: transform 0.5s ease;
    
}

.button:hover{
    transform: translate(0,-6px);
    box-shadow: 10px -10px 25px 0 rgba(143,64,248,0.5), -10px 10px 25px 0 rgba(39,200,255,0.5);
}

.button:hover::after{
    transform: rotate(150deg);
}

.purposes {
    padding-top: 100px;
    background-color: #6b7a8f;
}

.purposes h1{
    text-align: center;
    text-decoration: underline 5px #fbaf08;
    font-size: 55px;
    color: black;
    font-family: 'Montserrat', sans-serif;
    text-transform: uppercase;
}

.purposes-details{
    display: flex;
    justify-content: space-evenly;
    max-width: 80vw;
    height: 100vh;
    padding-top: 10vh;
    margin: 0 10vw 0 10vw;
}

.purpose-col{
    background-color: rgb(246, 246, 246);
    height: 50vh;
    padding: 2.5vw;
    width: 35vw;
    height: 75vh;
    border: 1px  black;
    border-radius: 10px;

}

.purpose-col a{
    color: #e05915;
    margin-top: 15px;
    padding-left: 180px;
    text-decoration: none;
    font-size: 25px;
    text-transform: uppercase;
    transition: .3s ease-in-out;
}

.purpose-col a:hover{
    font-size: 30px;
    letter-spacing: 2px;
}

.purpose-col p{
    padding-top: 10px;
    text-align: center;
}


.purpose-col img{
    width: 18vw;
    padding-left: 80px;
    margin-left: 40px;
    transition: .2s;
}

.purpose-col img:hover{
    width: 19vw;
}

#services-section{
    height: 180vh;
    /* background-color: #8cbcd0; */
    background-color: #fff;
    padding-top: 125px;
}

.service-heading{
    padding: 1px 0 50px 0;
    text-align: center;
    text-transform: uppercase;
    color: #51d0de;
    font-size: 50px;

}

/* categories section starts */

.service{
    display: flex;
    justify-content: space-evenly;
    max-width: 100vw;
}

.container-s {
    display: flex;
    position: relative;
  }
  
  .image {
    width: 27vw;
    height: 70vh;
  }
  
  .overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.75);
    overflow: hidden;
    width: 27vw;
    height: 0;
    transition: .5s ease;
  }
  
  .container-s:hover .overlay {
    height: 100%;
  }
  
  .text {
    color: white;
    font-size: 20px;
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    text-align: center;
  }

  .txt{
    text-transform: uppercase;
    padding: 20px;
  }

  /* ------------------------------------------ */
.service-1{
  padding-left: 50px;
    padding-top: 100px;
    display: flex;
    justify-content: space-evenly;
    max-width: 100vw;
}

  .container-1{
    display: flex;
    position: relative;
  }
  
  .image-1{
    width: 27vw;
    height: 70vh;
  }
  
  .overlay-1{
    position: absolute;
    bottom: 100%;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.75);
    overflow: hidden;
    width: 27vw;
    height:0;
    transition: .5s ease;
  }
  
  .container-1:hover .overlay-1{
    bottom: 0;
    height: 100%;
  }
  
  .text-1{
    color: white;
    font-size: 20px;
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    text-align: center;
  }

/* Q and A section */

.heading-faq{
    margin-top: 100px;
    text-align: center;
    font-size: 30px;
    color: silver;
    text-transform: uppercase;
    padding-bottom: 50px;
}

.container-faq {
    margin: 0 auto;
    padding: 0 4rem 4rem 4rem;
    width: 48rem;
  }
  
.accordion .accordion-item {
    border-bottom: 1px solid #e5e5e5;
  }
  
.accordion .accordion-item button[aria-expanded='true'] {
    border-bottom: 1px solid #03b5d2;
  }
  
.accordion button {
    position: relative;
    display: block;
    text-align: left;
    width: 100%;
    padding: 1em 0;
    color: #7288a2;
    font-size: 1.15rem;
    font-weight: 400;
    border: none;
    background: none;
    outline: none;
  }
  
.accordion button:hover,
.accordion button:focus {
    cursor: pointer;
    color: #03b5d2;
  }
  
.accordion button:hover::after,
.accordion button:focus::after {
    cursor: pointer;
    color: #03b5d2;
    border: 1px solid #03b5d2;
  }
  
.accordion button .accordion-title {
    padding: 1em 1.5em 1em 0;
  }
  
.accordion button .icon {
    display: inline-block;
    position: absolute;
    top: 18px;
    right: 0;
    width: 22px;
    height: 22px;
    border: 1px solid;
    border-radius: 22px;
  }
  
.accordion button .icon::before {
    display: block;
    position: absolute;
    content: '';
    top: 9px;
    left: 5px;
    width: 10px;
    height: 2px;
    background: currentColor;
  }
.accordion button .icon::after {
    display: block;
    position: absolute;
    content: '';
    top: 5px;
    left: 9px;
    width: 2px;
    height: 10px;
    background: currentColor;
  }
  
.accordion button[aria-expanded='true'] {
    color: #03b5d2;
  }
.accordion button[aria-expanded='true'] .icon::after {
    width: 0;
  }
.accordion button[aria-expanded='true'] + .accordion-content {
    opacity: 1;
    max-height: 9em;
    transition: all 200ms linear;
    will-change: opacity, max-height;
  }
.accordion .accordion-content {
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: opacity 200ms linear, max-height 200ms linear;
    will-change: opacity, max-height;
  }
.accordion .accordion-content p {
    font-size: 1rem;
    font-weight: 300;
    margin: 2em 0;
  }


   /* blog section  */


.blogs{
  padding-top: 100px;
}

   .blog {
    background: #eee;
    font-family: 'Kanit', sans-serif;
}

.blog-heading {
  padding-top: 100px;
    font-size: 20px;
    color: rgb(7, 7, 56);
    text-align: center;
}

.blog-heading span {
    padding: 1px 50px;
    background: orangered;
    color: white;
    clip-path: polygon(100% 0, 93% 50%, 100% 99%, 0% 100%, 7% 50%, 0% 0%);
}

.blog-box {
    display: flex;
    margin-right: 5vw;
    margin-left: 5vw;
    padding-bottom: 20px;
    justify-content: space-evenly;
}

.blog-col img {
    width: 100px;
    border: 1px solid white;
    border-radius: 70px;
    margin-left: 100px;
    margin-top: 30px;
    box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.7);
}

.blog-col {
    background: white;
    margin-left: 20px;
    width: 40vw;
    height: 50vh;
    outline: 1px solid grey;
    outline-offset: -14px;
    margin: 50px 0 100px 20px;
    transition: 0.3s;
}

.blog-col:hover {
    position: relative;
    width: 60vw;
    height: 55vh;
    outline: none;
    border: 2px solid black;
    border-radius: 10px;
    background: #eee;
    font-weight: bold;
    font-size: 18px;
    letter-spacing: 1px;
    cursor: pointer;
}

.blog-col p {
    text-decoration: none;
    color: black;
    text-align: center;
    padding: 20px 24px 0 24px;

}

.b-p {
    color: orangered;
}

  

  /* footer section */

.footer{
    width: 100%;
    display: inline-block;
    background: #333;
    height: 50vh;
    text-align: center;
    font-size: 22px;
    font-weight: 700;
    text-decoration: underline;
  }
  
  .footer-distributed{
      background: #666;
      box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
      box-sizing: border-box;
      width: 100%;
      text-align: left;
      font: bold 16px sans-serif;
      padding: 55px 50px;
  }
  
  .footer-distributed .footer-left,
  .footer-distributed .footer-center,
  .footer-distributed .footer-right{
      display: inline-block;
      vertical-align: top;
  }
  
  /* Footer left */
  
  .footer-distributed .footer-left{
      width: 40%;
  }
  
  /* The company logo */
  
  .footer-distributed h3{
      color:  #ffffff;
      font: normal 36px 'Open Sans', cursive;
      margin: 0;
  }
  
  .footer-distributed h3 span{
      color:  lightseagreen;
  }
  
  /* Footer links */
  
  .footer-distributed .footer-links{
      color:  #ffffff;
      margin: 20px 0 12px;
      padding: 0;
  }
  
  .footer-distributed .footer-links a{
      display:inline-block;
      line-height: 1.8;
    font-weight:400;
      text-decoration: none;
      color:  inherit;
  }
  
  .footer-distributed .footer-company-name{
      color:  #222;
      font-size: 14px;
      font-weight: normal;
      margin: 0;
  }
  
  /* Footer Center */
  
  .footer-distributed .footer-center{
      width: 35%;
  }
  
  .footer-distributed .footer-center i{
      background-color:  #33383b;
      color: #ffffff;
      font-size: 25px;
      width: 38px;
      height: 38px;
      border-radius: 50%;
      text-align: center;
      line-height: 42px;
      margin: 10px 15px;
      vertical-align: middle;
  }
  
  .footer-distributed .footer-center i.fa-envelope{
      font-size: 17px;
      line-height: 38px;
  }
  
  .footer-distributed .footer-center p{
      display: inline-block;
      color: #ffffff;
    font-weight:400;
      vertical-align: middle;
      margin:0;
  }
  
  .footer-distributed .footer-center p span{
      display:block;
      font-weight: normal;
      font-size:14px;
      line-height:2;
  }
  
  .footer-distributed .footer-center p a{
      color:  lightseagreen;
      text-decoration: none;;
  }
  
  .footer-distributed .footer-links a:before {
    content: "|";
    font-weight:300;
    font-size: 20px;
    left: 0;
    color: #fff;
    display: inline-block;
    padding-right: 5px;
  }
  
  .footer-distributed .footer-links .link-1:before {
    content: none;
  }
  
  /* Footer Right */
  
  .footer-distributed .footer-right{
      width: 20%;
  }
  
  .footer-distributed .footer-company-about{
      line-height: 20px;
      color:  #92999f;
      font-size: 13px;
      font-weight: normal;
      margin: 0;
  }
  
  .footer-distributed .footer-company-about span{
      display: block;
      color:  #ffffff;
      font-size: 14px;
      font-weight: bold;
      margin-bottom: 20px;
  }
  
  .footer-distributed .footer-icons{
      margin-top: 25px;
  }
  
  .footer-distributed .footer-icons a{
      display: inline-block;
      width: 35px;
      height: 35px;
      cursor: pointer;
      background-color:  #33383b;
      border-radius: 2px;
  
      font-size: 20px;
      color: #ffffff;
      text-align: center;
      line-height: 35px;
  
      margin-right: 3px;
      margin-bottom: 5px;
  }
</style>
    <script >
        const nav = document.querySelector('nav');
        let prevScrollpos = window.pageYOffset;

        window.addEventListener('scroll',()=>{
            let currentScrollpos = window.pageYOffset;

            if(prevScrollpos < currentScrollpos){
                nav.classList.add('hide');
            }else{
                nav.classList.remove('hide')
            }

            prevScrollpos = currentScrollpos;
        })

        const items = document.querySelectorAll('.accordion button');

function toggleAccordion() {
  const itemToggle = this.getAttribute('aria-expanded');

  for (i = 0; i < items.length; i++) {
    items[i].setAttribute('aria-expanded', 'false');
  }

  if (itemToggle == 'false') {
    this.setAttribute('aria-expanded', 'true');
  }
}

items.forEach((item) => item.addEventListener('click', toggleAccordion));   

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>