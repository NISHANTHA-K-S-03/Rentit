<?php
  session_start();

  if(!(isset($_SESSION['userid'])))
{
  header('location:login&register.php');
}
  $adminid=$_SESSION['userid'];
  $con=mysqli_connect('localhost','root','');
  mysqli_select_db($con,'rentit');
 
  $query="select count(*) as total from item;";
  $result=mysqli_query($con,$query);
  $data=mysqli_fetch_assoc($result);

  $query1="select count(*) as total1 from item_orders;";
  $result1=mysqli_query($con,$query1);
  $data1=mysqli_fetch_assoc($result1);

  $query2="select count(*) total2 from seller;";
  $result2=mysqli_query($con,$query2);
  $data2=mysqli_fetch_assoc($result2);

  $query3="select count(*) total3 from customer;";
  $result3=mysqli_query($con,$query3);
  $data3=mysqli_fetch_assoc($result3);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="st1.css">
    <link rel="stylesheet" href="CSS/sellerhome.css">
    <link rel="stylesheet" href="CSS/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
      .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 60px;
      background-color: #AAC8A7;
      color: #fff;
      padding: 0 20px;
    }
  
    .navbar-brand {
      font-size: 24px;
      font-weight: bold;
      text-decoration: none;
      color: #fff;
      margin: 0;
    }
  
    .logout-btn {
      background-color: #146C94;
      color: #fff;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
    }
      .column:hover
      {
        background-color: #363945;
      }

      .container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 50vh;
}

      .button
      {
        background-color:whitesmoke;
        border-radius:10px;
        text-transform:uppercase; 
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
        margin-top: 20px;
      }
      .button:hover
      {
        background-color:green;
      }
    </style>

</head>

<body style="background-color: #CBFFA9;
background-repeat: no-repeat;
background-size: 100%;
background-attachment: fixed;">
    <nav class="navbar">
    <div>
      <!-- Left part of the navbar -->
    </div>
    <a class="navbar-brand" href="index.php">RentIt!</a>
    <div>
      <a class="logout-btn" href="logout.php">Logout</a>
    </div>
  </nav>

            <h3 style="color: #F1C93B;
            text-transform: uppercase;
            margin-left:3%;
            margin-top:2%;
             font-family: 'Arial';
             text-align:center;">Hello &nbsp;<?php
            if(isset($_SESSION['userid']))
            {
              echo $_SESSION['userid'];
            }
            else{
              header('location:login&register.php');
            }?></h3>

          <div class="container1">
          <h3 style="color: #F1C93B;
          text-transform: uppercase;">Dashboard</h3>
           
          <div class="row">
            <div  class="column "><h4 style="font-family: 'Arial';">Total count of items :<h4><?php echo $data['total'];?></h4></h4></div>
            <div class="column"><h4 style="font-family: 'Arial';">Total orders placed:</h4><h4><?php echo $data1['total1'];?></h4></div>
            <div class="column"><h4 style="font-family: 'Arial';">Total sellers registered:</h4><h4><?php echo $data2['total2'];?></h4></div>
            <div class="column"><h4 style="font-family: 'Arial';">Total Customers registered:</h4><h4><?php echo $data3['total3'];?></h4></div>
           </div>
           </div>
            <div class="container">
           <div class="buttons">
  <button class="button" onclick="window.location.href = 'adminitemview.php'">View items</button>
  <button class="button" onclick="window.location.href = 'adminsellerview.php'">View seller information</button>
  <button class="button" onclick="window.location.href = 'admincustomerview.php'">View Customer information</button>
  <button class="button" onclick="window.location.href = 'adminordersview.php'">View Order information</button>
  <button class="button" onclick="window.location.href = 'addadmin.php'">Add admin</button>
</div>
</div>



</body>
</html>