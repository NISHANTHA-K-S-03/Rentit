<?php
  $con=mysqli_connect('localhost','root','');
  $crpid=$_POST['del'];
  session_start();

  if($con->connect_error)
  {
    die("Connection error");
  }
  
  mysqli_select_db($con,'rentit');
  $deletequery="DELETE from item where item_id=$crpid";
  mysqli_query($con,$deletequery);
  header('refresh:3; url=adminitemview.php');
        echo "<h2 style='text-align:center;
        margin-top:10%;color:red;
        text-transform:uppercase;'>selected item is deleted by admin</h2>";
  ?>