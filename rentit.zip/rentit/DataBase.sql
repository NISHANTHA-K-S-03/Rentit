SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Table structure for table `item`

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_category` varchar(50) NOT NULL,
  `item_type` varchar(100) NOT NULL,
  `seller_id` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cost` float NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table `item`

INSERT INTO `item` (`item_id`, `item_name`, `item_category`, `item_type`, `seller_id`, `quantity`, `cost`, `datetime`) VALUES (05, 't-shirt', 'daily item', 'clothes', 's101', 10, 100, '2023-06-28 11:10:50'),
(06, 'stethoscope', 'professional item', 'medical', 's101', 3, 50, '2023-06-28 11:10:50');

-- Table structure for table `item_orders`

CREATE TABLE `item_orders` (
  `item_id` int(4) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `seller_id` varchar(200) NOT NULL,
  `total_cost` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `dateandtime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table `item_orders`

INSERT INTO `item_orders` (`item_id`, `customer_id`, `seller_id`, `total_cost`, `quantity`, `dateandtime`) VALUES (01, 'c101', 's101', 1000, 10, '2023-06-29 04:25:58'),
(02, 'c101', 's101', 300, 3, '2023-06-29 11:10:50'),
(03, 'c101', 's101', 1200, 15, '2023-06-29 13:15:47'),
(04, 'c101', 's102', 500, 2, '2023-06-29 13:15:47');

-- Table structure for table `customer`

CREATE TABLE `customer` (
  `customer_id` varchar(200) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table `customer`

INSERT INTO `customer` (`customer_id`, `customer_name`, `phone_number`, `email`, `city`) VALUES ('c101', 'nishantha', '7618798561', 'ksnishantha02@gmail.com', 'shivamogga');

-- Table structure for table `seller`

CREATE TABLE `seller` (
  `seller_id` varchar(100) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table `seller`

INSERT INTO `seller` (`seller_id`, `seller_name`, `phone_number`, `email`, `city`) VALUES ('s101', 'pramath', '9901285584', 'pramathvbhat@gmail.com', 'uttara kannada'),
('s102', 'pranav', '9906574123', 'pranavbc@gmail.com', 'bengaluru');

-- Table structure for table `login`

CREATE TABLE `login` (
  `user_id` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table `login`

INSERT INTO `login` (`user_id`, `password`, `role_id`) VALUES ('admin1', '1111', 1),
('admin2', '1111', 1),
('c101', '3333', 3),
('s101', '2222', 2),
('s102', '2222', 2);

-- Table structure for table `role`

CREATE TABLE `role` (
  `role_id` int(50) NOT NULL,
  `role_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table `role`

INSERT INTO `role` (`role_id`, `role_name`) VALUES (1, 'admin'),
(2, 'seller'),
(3, 'customer');

-- Indexes for dumped tables

-- Indexes for table `item`

ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`,`item_name`,`item_category`),
  ADD KEY `seller_id` (`seller_id`);

-- Indexes for table `item_orders`

ALTER TABLE `item_orders`
  ADD KEY `item_orders_ibfk_5` (`seller_id`),
  ADD KEY `item_orders_ibfk_3` (`customer_id`);

-- Indexes for table `customer`

ALTER TABLE `customer`
  ADD KEY `customer_id` (`customer_id`);

-- Indexes for table `seller`

ALTER TABLE `seller`
  ADD KEY `seller_id` (`seller_id`);

-- Indexes for table `login`

ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`);

-- Indexes for table `role`

ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

-- AUTO_INCREMENT for dumped tables

-- AUTO_INCREMENT for table `item`

-- ALTER TABLE `item`
--   MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

-- Constraints for dumped tables

-- Constraints for table `item`

ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `login` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Constraints for table `item_orders`

ALTER TABLE `item_orders`
  ADD CONSTRAINT `item_orders_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `login` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `item_orders_ibfk_5` FOREIGN KEY (`seller_id`) REFERENCES `login` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Constraints for table `customer`

ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `login` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Constraints for table `seller`

ALTER TABLE `seller`
  ADD CONSTRAINT `seller_id` FOREIGN KEY (`seller_id`) REFERENCES `login` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;